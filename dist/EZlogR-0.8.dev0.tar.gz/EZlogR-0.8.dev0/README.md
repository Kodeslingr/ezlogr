This app will make collecting and viewing logs from Python projects EZ!
