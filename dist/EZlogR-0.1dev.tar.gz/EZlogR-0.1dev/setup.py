from distutils.core import setup

setup(
    name='EZlogR',
    version='0.1dev',
    packages=['ezlogr',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read(),
)